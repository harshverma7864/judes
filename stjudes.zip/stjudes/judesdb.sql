-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2022 at 01:01 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `judesdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `sno` int(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `imageurl` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`sno`, `title`, `imageurl`) VALUES
(1, 'Christmas Celebrations', 'https://stjudescollege.org/uploads/xmasceleb2018/1.jpeg'),
(2, 'Christmas Celebrations', 'https://stjudescollege.org/uploads/xmasceleb2018/5.jpeg'),
(3, 'Christmas Celebrations', 'https://stjudescollege.org/uploads/xmasceleb2018/7.jpeg'),
(4, 'Christmas Celebrations', 'https://stjudescollege.org/uploads/xmasceleb2018/7.jpeg'),
(5, 'School Picnic', 'https://stjudescollege.org/uploads/school_picnicdec2018/2.jpeg'),
(6, 'School Picnic', 'https://stjudescollege.org/uploads/school_picnicdec2018/2.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `imageurls`
--

CREATE TABLE `imageurls` (
  `sno` int(11) NOT NULL,
  `url` varchar(100) NOT NULL,
  `category` varchar(40) NOT NULL,
  `section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `imageurls`
--

INSERT INTO `imageurls` (`sno`, `url`, `category`, `section`) VALUES
(1, '../img/वर्ष परिवर्तन पर सदा ,   करें प्रभु का गुणग', 'specialize', ''),
(2, 'https://stjudescollege.org/manifest/academics.jpg', 'Academics', 'specialize'),
(3, 'https://stjudescollege.org/manifest/basketball-stjudes.jpg', 'Sports', 'specialize'),
(4, 'https://stjudescollege.org/manifest/cultural.jpg', 'Co-Curricular Activities', 'specialize'),
(5, 'https://stjudescollege.org/manifest/computer-lab-stjudes.jpg', 'Information Tech Lea', 'specialize');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `sno` int(11) NOT NULL,
  `Notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`sno`, `Notice`) VALUES
(1, 'Keeping in view the gravity of Corona Virus the Report Card distribution which was scheduled on 21st March 2020 is Postponed till further Government Orders. You will informed about the New Date of Report Card distribution. Stay home Stay Safe'),
(2, 'Dear Parents, Timings from 24.Feb.2020 Monday to Saturday 8:20 am to 11:10 am Pre-Primary 9:30 am to 12 pm Regards, Principal'),
(3, 'Dear Parents, Admit Cards of your ward studying in Class X will issued on 13.Feb.2020 at 9:00 hrs. Please clear all your pending fee accordingly. Regards, Principal'),
(4, 'Dear Parents, A Reminder School timing from 10 feb 2020 [Monday -Friday] Class I- VIII 8: 20 am to 1: 40 pm Pre-Primary - 9: 30 am - 12: 30 pm Saturday Class I-VIII 8: 20 am -12: 30 pm Pre-Primary 9: 30 am - 11: 20 pm Regards, Principal@');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `sno` int(5) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Class` varchar(6) NOT NULL,
  `Rank` int(2) NOT NULL,
  `Fyear` varchar(8) NOT NULL,
  `Percentage` varchar(6) NOT NULL,
  `imageurl` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`sno`, `Name`, `Class`, `Rank`, `Fyear`, `Percentage`, `imageurl`) VALUES
(1, 'Atharv Dubey', '10', 1, '2019-20', '94.8', 'http://localhost/stjudes/img/AtharvaDubey.jpg'),
(2, 'Swara Dubey', '10', 2, '2019-20', '93', 'http://localhost/stjudes/img/AtharvaDubey.jpg'),
(3, 'Swara Dubey', '12', 1, '2019-20', '95', 'http://localhost/stjudes/img/AtharvaDubey.jpg'),
(4, 'Swara Dubey', '10', 2, '2018-19', '45', 'http://localhost/stjudes/img/AtharvaDubey.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `sno` int(11) NOT NULL,
  `Event` varchar(40) NOT NULL,
  `Date` varchar(30) NOT NULL,
  `actionurl` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`sno`, `Event`, `Date`, `actionurl`) VALUES
(1, 'Final Term Schedule', '19 February 2020', 'https://stjudescollege.org/schedules/final-term-schedule.pdf'),
(2, '2nd Unit Schedule', '04 January 2020', 'https://stjudescollege.org/schedules/final-term-schedule.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `sno` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `section` varchar(30) NOT NULL,
  `imageurl` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`sno`, `Name`, `designation`, `section`, `imageurl`) VALUES
(1, 'Fahd Azeem', 'President', 'managerial', 'https://stjudescollege.org/uploads/vice-president-main.jpg'),
(2, 'Late Javead-Ul-Azeem', 'Former President', 'managerial', 'https://stjudescollege.org/uploads/president.jpg'),
(3, 'Azra Azeem', 'Seceratary', 'managerial', 'https://stjudescollege.org/uploads/secretary.jpg'),
(4, 'Abeera Ali', 'teacher', 'teacher', 'https://stjudescollege.org/uploads/teachers/new/Abeera%20Ali.jpg'),
(5, 'Akshay Srivastava', 'teacher', 'teacher', 'https://stjudescollege.org/uploads/teachers/new/Akshay%20Srivastava.jpg'),
(6, 'Amandeep', 'teacher', 'teacher', 'https://stjudescollege.org/uploads/teachers/new/Amandeep.jpg'),
(7, 'Amit Kumar Tripathi', 'teacher', 'teacher', 'https://stjudescollege.org/uploads/teachers/new/Amit%20Kumar%20Tripathi.jpg'),
(8, 'Aparna Trivedi', 'teacher', 'teacher', 'https://stjudescollege.org/uploads/teachers/new/Aparna%20Trivedi.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `userqueries`
--

CREATE TABLE `userqueries` (
  `sno` int(11) NOT NULL,
  `Useremail` varchar(30) NOT NULL,
  `Usercontact` varchar(11) NOT NULL,
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userqueries`
--

INSERT INTO `userqueries` (`sno`, `Useremail`, `Usercontact`, `query`) VALUES
(1, 'harshverma7864@gmail.com', '9140203313', 'i want to know the fee structure of the college'),
(2, 'rohanvema@gmail.com', '7897662407', '   i want to know the address of the colege\r\n  ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `imageurls`
--
ALTER TABLE `imageurls`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `userqueries`
--
ALTER TABLE `userqueries`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `imageurls`
--
ALTER TABLE `imageurls`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `sno` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `userqueries`
--
ALTER TABLE `userqueries`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
