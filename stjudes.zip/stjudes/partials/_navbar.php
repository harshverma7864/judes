<!-- <div class="Navbar2">
        <div class="navtabs">
            <ul>
                <a href=""><li><img src="https://stjudescollege.org/uploads/assets/stlogonew.png" width="30" height="30">&nbsp; &nbsp; St. Jude's College</li></a>
                <a href="index.php"><li>Home</li></a>
                <a href="results.php"><li>Results</li></a>
                <a href="notice.php"><li>Noticeboards</li></a>
                <a href="schedule.php"><li>Schedule</li></a>
                <a href="gallery.php"><li>Jude's Gallery</li></a>
                <a href="about.php"><li>About</li></a>
                <a href="contact.php"><li>Contact</li></a>
            </ul>
        </div>
    </div> -->


    <nav class="px-3 navbar navbar-expand-lg shadow-lg navbar-light bg-light">
        
  <div class="container-fluid">
  <a href="" class="navbar-brand"><li style="list-style:none;"><img src="https://stjudescollege.org/uploads/assets/stlogonew.png" width="30" height="30"><span class="sclname"> St. Jude's College</span></li></a>
    <!-- <a class="navbar-brand" href="#">Navbar</a> -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/index.php"><b>Home</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/php/results.php?yr=2019-20"><b>Results</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/php/notice.php"><b>Noticeboards</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/php/schedule.php"><b>Schedule</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/php/gallery.php"><b>Jude's Gallery</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/php/about.php"><b>About</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/php/contact.php"><b>Contact</b></a>
        </li>
      </ul>
    </div>
  </div>
</nav>
