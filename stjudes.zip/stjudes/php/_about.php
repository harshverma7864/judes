<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/about.css">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>   
     <title>Welcome - Jude's College
    </title>
</head>
<body>

<?php include '../partials/_dbconnect.php';?>
    <?php include '../partials/_navbar.php';?>



<div class="container">



<?php 

if ($_GET['type'] == "Anthem") {
    echo "
    <p>
    School Anthem<br>
    Carrying High the banners of St. Jude's<br>
    We March in the light of Lord.<br>
    Unity Love and brotherhood, forever to remain in our hearts<br>
    Knowledge is Light<br>
    Knowledge is life<br>
    We Carry this Torch With Pride<br>
    Carrying high the banners of St. Jude's<br>
    Removing the darkness of ignorance<br>
    With the light of knowledge we receive<br>
    Courage to oppose all evil<br>
    In peace and goodness we believe.<br>
    Carrying high the banners of St. Jude's...<br>
    Knowledge is Light<br>
    Onward We March, labour and toil<br>
    We learn, we grow and we give<br>
    using our powers and our talents<br>
    for goodwill in the world to bring.<br>
    
    Carrying high the banners of St. Jude's<br>
    Knowledge is Light.....<br>
    We promise to keep. we promise to abide<br>
    by the high ideals of our school<br>
    always to be disciplined in life<br>
    Where ever in the world we be.<br>
    Carrying high the banners of St. Jude's<br>
    Knowledge is Light.....<br>
    We pray to God for everlasting peace<br>
    to our founder Azeem.<br>
    With whose efforts, labour and toil<br>
    our institution grows day by day.<br>
    Carrying high the banners of St. Jude's<br>
    Knowledge is Light.....<br>
    Carrying high the banners of St. Jude's<br>
    Knowledge is Light.....<br></p>
    ";
 }

else if($_GET['type'] == "RulesandRegulations"){
 echo " 
    <p><h3>For Attention Of Parents</h3><br><br>
    1. We have taken the responsibility of your ward to equip them with moral fibre and skill to complete and excel in the changed situation.<br>
    2. Instructions regarding academic, co-curricular activities and Dress Code may not be shunned, they are only meant to bring out the hidden talent of your ward. Your co-operation in these matters is obligatory.<br>
    3. In the new millennium we continue to strive to equip your ward not only academically but with such abilities as may be provided in the great Metros and, therefore, the regulated dress code and other instructions for the occasion are only meant to complete with the outstanding institutions of the Metros. If these are overlooked, you may feel our ignorance in maintaining track record.<br>
    4. Parents/Guardians are requested to notify the college of any change in address or telephone number.<br>
    5. Students of classes VI to XII, if found guilty or practicing any of the following, will be suspended from the college with immediate action :<br>
    ~ Use of any cell phone or any other electronic gadget is not allowed in the college [except calculators for ISC students].<br>
    ~ Motorbikes are not allowed. If spotted anywhere outside the college, indulged in illegal activity or misconduct in school uniforms during all the six working days [Mon. to Sat.].<br>
    ~If absent for any reason from the school, should get the Absence Record - Column filled in the school-diary along with an application duly signed by the parent/guardian.<br>
    6. If his/her behavior is not good. The following will be regarded as misconduct.<br>
    (a) Obscene behavior.<br>
    (b) Spitting or writing on the walls.<br>
    (c) Foul/Abusive Language.<br>
    (d) Failure to attend or participate in Co-curricular Programmes.<br>
    (e) Indifference Towards Students.<br>
    (f) Destruction of school property.<br>
    (g) Indulgence in subversive activities.<br>
    (h) Irregular Attendance<br>
    (i) Adopting unfair Means at the examination.<br><br>
    <h3>General Rules</h3><br>
    1. Students are responsible to college authorities not only for their conduct in college but also for their general behavior outside. Any report, observed objectionable outside the college on the part of a student wit make him/her liable to disciplinary action a. may result in the removal of student from the college.<br>
    2. Politeness courtesy and implicit obedience is expected at all time. Students have the opportunity to attend and conduct several assemblies during the academic year. These assemblies are an important part of the college programme and learning process. It is essential that students conduct themselves 0a proper manner while at assembly and when moving to and from the assembly. Attendance at assembly is compulsory for all students.<br>
    3. The college discipline policy has been developed to create and main-fain an environment in which optimal learning can take place. An effective college discipline policy encourages; n positive teaming environment and minimizes the potential for disruptive behavior. Discipline does not imply punishment, it does imply development of attitude in a person which leads her to respect the necessity for regulation desire leading to respect. College discipline requires the partnership of parents, students and staff to work together. Students should maintain a, solute silence during morning Assembly and while moving into classrooms. Silence should also be observed while moving to/or from PT. classes and the Library or Laboratories.<br>
    4. The basic rights :- (a) The right to be safe. (b) The right to feel safe. (c) The right to beam in an environment that is free of disrespectful and disruptive behavior.<br>
    5. Home work is an important aspect of the total teaming process and serves as an extension of the class room. It is generally assigned to Strengthen skill through practi., to deepen and enrich understanding. of concepts to improve study habits and to achieve instructional objective.<br>
    6. Students must avoid writing and scratching on the walls furniture or in any way damaging; college property. Throwing of ink and paint is very objectionable, Any damage done must be made goods. In addition, a heavy fine rnay also be imposed.<br>
    7. the college does not accept responsibility for the loss of books, money clothes gold/silver rings/earrings, watches etc. students should not bring valuables to the college.<br>
    8. Students Must converse in English always while in college and maintain a high standard in their conversation.</p><br>
    
       ";
}

else{
    echo "
    
    
    <p>
    <h3>Dress Code & School Conduct</h3><br>
Uniform<br>
It is compulsory for all students to wear the prescribed College Uniform, Students Who do not conform to dress regulations given below will not be permitted to attend classes and may be sent back home.<br><br>
Boys:<br>
<br>
1. White shirts single breast pocket (Half-Sleeves) April-Oct.<br>
2. White shirt single breast pocket (Full-Sleeves) Nov-March.<br>
3. Dark Grey Shorts for classes Prep. to V.<br>
4. Dark grey trousers for classes VI to XII.<br>
5. Black Nylon Socks<br>
6. Black Leather Shoes<br>
7. College tie and belt (available in the College Office)<br>
8. (i) During winter, single-breasted blazer with the college crest.<br>
(ii) College Pullover -<br>
Students other than sikh boys are not permitted to attend the college with long hair or long side lock.<br><br>
Girls<br>
<br>
1. Dark grey pinator upto the knee-Square neck & side closed.<br>
2. White blouse (Half Sleeves) April-Oct/(Full Sleeves) Nov-March<br>
3. Black Leather shoes and black nylon socks.<br>
4. College tie and belt (available in the College Office)<br>
5. (i) During winter, single-breasted blazer with the college crest.<br>
(ii) College Pullover (available at the College Office)<br>
<h2>Games/Sports Uniform</h2><br><br>
<h3>Games:</h3><br><br>
Boys<br>
1. White Half Shorts.<br>
2. House Colour T-shirts (available in the college office).<br><br>
Girls<br>
1. White divided skirts.<br>
2. House Colour T-shirts (available in the college office).<br><br>
<h3>Sports:</h3><br>
Boys<br>
1. White trousers (for P.T)<br>
2. White Half Shirts (for P.T)<br>
Girls<br>
1. White divided skirts<br>
2. White Half shirts<br>
No student should be seen in a public place in the College uniform<br>
    </p>
    
    
     ";
}


?>



</div>



<?php include '../partials/_footer.php'; ?>

</body>

</html>