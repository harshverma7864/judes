<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>

    <title>Welcome - Jude's College
    </title>

    <style>
        .row{
            width: 100%;
        }
    </style>
</head>
<body>

<?php include '../partials/_dbconnect.php';?>
    <!-- Navbar  -->
    <?php include '../partials/_navbar.php';?>
    <div class="noticeboard text-center">
        <h1>Noticeboard</h1>
    </div>



    <div class="row">
        <div class="col-md-12">
            <div class="container d-flex justify-content-center">
            <div class="row">
                <?php

                $sql= "select * from notice";
                $result = mysqli_query($conn,$sql);

                while($row = mysqli_fetch_assoc($result)){
                    echo '
                <div class="col-sm-6">
                    <div class="noticecard shadow p-3 mb-5 bg-body rounded">
                    <div class="card-body">
                        <h5 style="border-bottom:1px solid grey;" class="text-center py-3" class="card-title">Notice #'.$row['sno'].'</h5>
                        <p class="" style="font-weight:lighter;">'.$row['Notice'].'</p>
                        <h6 style="display:block; top:70vh;" class="mx-3"><b>Principal</b></h6>
                    </div>
                </div>
                </div>';
                }
            ?>
            </div>
        </div>
    </div>
    
</body>
</html>