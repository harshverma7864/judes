<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>

    <title>Welcome - Jude's College
    </title>

    <style>
        .container2{
            width: 80%;
            margin:auto;
            border:2px solid grey;
            border-radius:10px;
            margin-top:10vh;
        }
    </style>
</head>
<body>

<?php include '../partials/_dbconnect.php';?>

    <!-- Navbar  -->
    <?php include '../partials/_navbar.php';?>

    <div class="noticeboard text-center"><br><br>
        <h1>Schedules</h1>
    </div>

    <div class="container2">

    <table class="px-3 table">
  <thead>
    <tr>
      <th scope="col">Event</th>
      <th scope="col">Date Updated</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>

  <?php 

  $sql = "select * from schedules";
  $result = mysqli_query($conn,$sql);

  while($row = mysqli_fetch_assoc($result)){
  echo ' <tr>
  <td>'.$row['Event'].'</td>
  <td>'.$row['Date'].'</td>
  <td><a href="'.$row['actionurl'].'">Actions</a></td>
</tr>';
  }
   
    ?>
  
  </tbody>
</table>
</div>


</body>
</html>