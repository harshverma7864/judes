<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="/bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>

    <title>Welcome - Jude's College</title>
</head>
<body>

<?php include 'partials/_dbconnect.php';?>

    <!-- Navbar  -->
    <?php include 'partials/_navbar.php';?>

    <!-- Main  -->

    <section class="section1">
        <h1 class="main-heading">We Are the 'Judians'</h1>
        <button class="btn shadow-lg btn-light">Know More About College</button>
    </section>


    <section class="section2">
        <h1>We Specialize In</h1>
        <div class="cardss d-flex justify-content-center">
        <div class="row ">
        <!-- <div class="cards"> -->

        <?php

        $sql = "Select * from imageurls where section = 'specialize'";
        $result = mysqli_query($conn, $sql);
        // print($result);

        while($row = mysqli_fetch_assoc($result)){
            echo 
            '<div class="col-md-4">
            <div class="shadow-lg card">
                <img src="'.$row['url'].'" alt="">
                <p class="mx-3 my-2">'.$row['category'].'</p>
            </div>
            </div>';
        }
        ?>

        <!-- </div> -->
      
        </div>
        </div>
    </section>



        <section class="section3">
            <h1>Jude's Stream</h1>
            <div class="cards">
                <div class="card3">
                    <img src="https://stjudescollege.org/productives/science.svg" alt="">
                    <h1>PCM</h1>
                    <p>Physics , chemistry , Maths , English , and 5th subject (Optional)</p>
                </div>
                <div class="card3">
                    <img src="https://stjudescollege.org/productives/biology.svg" alt="">
                    <h1>PCB</h1>
                    <p>Physics , chemistry , Biology , English , and 5th subject (Optional)</p>

                </div>
                <div class="card3">
                    <img src="https://stjudescollege.org/productives/commerce.svg" alt="">
                    <h1>Commerce</h1>
                    <p>Accountancy , Economics , Commerce , English , and 5th subject (Optional)</p>
                </div>
            </div>
        </section>



        <section class="section4">
            <h1>Did You Know ?</h1>

            <div class="cardss4 d-flex justify-content-center">
            <div class="row">
            <div class="col-md-12">
            <div class="cards">
                <div class="card4">
                    <img src="https://stjudescollege.org/manifest/basketball-stjudes.jpg" alt="">
                    <p>First Basket Ball court in Unnao Was Constructed in St. Jude's College</p>
                </div>
                <div class="card4">
                    <img src="https://stjudescollege.org/manifest/computer-lab-stjudes.jpg" alt="">
                    <p>The First Computer & Digital Lab in Unnao Was Established in St. Jude's College </p>

                </div>
                </div>
                </div>
                </div>
            </div>
        </section>



     <section class="section5">
        <div class="vacancies">
            <p>We Have vacancies For Various Posts , Call Us at <span style="color: blue;">+917275094064</span> For More Info.</p>
        </div>

        <div class="offer">
            <p>50% Off On Admission Fees For Nursery Class.</p>
        </div>
    </section>
    <?php include 'partials/_footer.php'; ?>
      
</body>
</html>