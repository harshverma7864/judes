<?php 
define("MYSITE",True);

include './_dbconnect.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "Select * from admins where username = '$username'";
$result = mysqli_query($conn,$sql);

$row = mysqli_fetch_assoc($result);

$upassword = $row['password'];

if ($password == $upassword) {
    session_start();
    $_SESSION['username'] = $username;
    $_SESSION['role'] = "admin";
    $alert = "Login successfull";
    header("location: ../php/results.php?alert=$alert");
}
else{
    $alert = "wrong credentials";
    header("location: /stadminpanel?alert=$alert");
}





?>