  <?php session_start(); 

 if($_SESSION['role'] != "admin"){
    $alert = "login first";
    header("location: /stadminpanel?alert=$alert");
 }

  ?>
    <nav class="px-3 navbar navbar-expand-lg shadow-lg navbar-light bg-light">
        
  <div class="container-fluid">
  <a href="" class="navbar-brand"><li style="list-style:none;"><img src="https://stjudescollege.org/uploads/assets/stlogonew.png" width="30" height="30"><span class="sclname"> St. Jude's College</span></li></a>
    <!-- <a class="navbar-brand" href="#">Navbar</a> -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="/stadminpanel/php/results.php"><b>Results</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/stadminpanel/php/notice.php"><b>Noticeboards</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/stadminpanel/php/schedule.php"><b>Schedule</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/stadminpanel/php/gallery.php"><b>Jude's Gallery</b></a>
        </li>   
        <li class="nav-item">
          <a class="nav-link" href="/stadminpanel/partials/handlelogout.php"><b>Logout</b></a>
        </li>   
        <li class="nav-item">
          <a class="nav-link" href=""><b><?php echo $_SESSION['username']; ?></b></a>
        </li>   
      </ul>


    </div>
  </div>
</nav>
