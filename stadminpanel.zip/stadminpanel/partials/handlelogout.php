<?php 


$_SESSION['username'] = NULL;
$_SESSION['role'] = NULL;
session_destroy();
clearstatcache();
$alert = "Logged out Successfully";

header("location: /stadminpanel?alert=$alert");

?>