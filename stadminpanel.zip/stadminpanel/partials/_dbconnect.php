<?php 

if(defined("MYSITE")){

    $servername= "localhost";
    $username = "root";
    
    $database = "judesdb";
    $password = "";
    
    $conn = mysqli_connect($servername,$username,$password,$database);
    
    
}




?>