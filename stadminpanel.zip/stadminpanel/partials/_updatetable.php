<?php

define("MYSITE",True);

include './_dbconnect.php';
if ($_GET['type'] == "notice") {
    $note = $_POST['notice'];
    $sql = "INSERT INTO `notice` (`sno`, `Notice`) VALUES (NULL, '$note')";
    $result = mysqli_query($conn,$sql);
    if ($result) {
        $alert = "Notice Published";
        header("location: /stadminpanel/php/notice.php?alert=$alert");
    }
}


if ($_GET['type'] == "gallery") {
    $name = $_POST['Title'];
    $class = $_POST['class'];
    $rank = $_POST['rank'];
    $year = $_POST['year'];
    $percentage = $_POST['per'];
    $sql = "INSERT INTO `results` (`sno`, `Name`, `Class`, `Rank`, `Fyear`, `Percentage`) VALUES (NULL, '$name', '$class', '$rank', '$year', '$percentage')";
    $result = mysqli_query($conn,$sql);
    if ($result) {
        $alert = "Data uploaded";
        header("location: /stadminpanel/php/results.php?alert=$alert");
    }
}


?>