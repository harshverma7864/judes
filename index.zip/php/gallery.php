<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
    <title>Welcome - Jude's College
    </title>

    <style>
        .row{
            margin:5vh;
            width:90%;
        }
        .imagecard{
            width:70%;
            height:40vh;
            margin-bottom:10vh;
            border:2px solid white;
            border-radius:20px;
        }
        .imagecard > img{
            width:100%;
            height:100%;
        }
        
        .col-md-4{
            margin:auto;
        }
        .card > a{
            text-decoration:none;
            color:black
        }
        .card{
            min-height:35vh;
        }

        @media screen and (max-width:700px) {
            .card{
            min-height:50vh;
        }
        }
    </style>
</head>
<body>

<?php include '../partials/_dbconnect.php';?>
    <!-- Navbar  -->
    <?php include '../partials/_navbar.php';?>


<div class="galary ">
    <div class="row text-center ">
        <?php
             $sql= "select distinct title from gallery";
             $result = mysqli_query($conn,$sql);
             

             

             while($row = mysqli_fetch_assoc($result)){
                $title = $row['title'];
                 
             
                 $sql2 = "select * from gallery where title = '$title' limit 1";
                 $result2 = mysqli_query($conn,$sql2);
                 while($row2 = mysqli_fetch_assoc($result2)){

                echo'
                <div class="card  col-md-4 my-3 ">
                <a href="./imagegallery.php?title='.$title.'">
                    <div class="col-md-4 my-3" style=" width:100%; height:80%; display:flex;justify-content:center;">
                        <div class="imagecard" style=" width:100%; height:60%;" >
                            <img src="../img/events/'.$row2['foldername'].'/'.$row2['imageurl'].'" alt="">
                            '.$title.'
                        </div>
                    </div>
                    </a>
                </div>
                ';
                 }
                
               
    }
    ?>
    </div>
    </div>

</body>

</html>