<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
    <title>Welcome - Jude's College
    </title>

    <style>
        .row{
            margin:5vh;
            width:90%;
        }
        .imagecard{
            width:70%;
            height:40vh;
            margin-bottom:10vh;
            border:2px solid white;
            border-radius:20px;
        }
        .imagecard > img{
            width:100%;
            height:100%;
        }
        .imagecard:hover{
            transform:scale(1.1);
            transition: linear 0.5s;
        }
        .col-md-4{
            margin:auto;
        }
    </style>
</head>
<body>

<?php include '../partials/_dbconnect.php';?>
    <!-- Navbar  -->
    <?php include '../partials/_navbar.php';?>


<div class="galary ">
    <div class="row text-center ">
        <?php
            
             

                $title = $_GET['title'];
                 echo '<h1>'.$title.'</h1>';
             
                 $sql2 = "select * from gallery where title = '$title'";
                 $result2 = mysqli_query($conn,$sql2);
                 while($row2 = mysqli_fetch_assoc($result2)){

                echo'
                    <div class="col-md-4 my-3" style="  display:flex;justify-content:center;">
                        <div class="imagecard"  >
                            <img src="../img/events/'.$row2['foldername'].'/'.$row2['imageurl'].'" alt="">
                            
                        </div>
                    </div>
                ';      
    }
    ?>
    </div>
    </div>

</body>

</html>