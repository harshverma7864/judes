<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/result.css">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>

    <title>Results</title>
</head>

<body>

    <?php include '../partials/_dbconnect.php';?>

    <!-- Navbar  -->
    <?php include '../partials/_navbar.php';?>

    <?php
        $year = $_GET['yr'];
    ?>


    <div class="container my-3">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" href="results.php?yr=2021-22">Results 2021-22</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="results.php?yr=2020-21">Results 2020-21</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="results.php?yr=2019-20">Results 2019-20</a>
            </li>
        </ul>
    </div>


    <div class="Result">
        <div class="Rcontainer">
            <h2 class="text-center">ICSE Class 10<sup>nth</sup> toppers <?php echo $year ?> </h2>

            <div class="resultcards d-flex justify-content-center">
                <div class="row">


    <?php
        $sql = "Select * from results where Fyear = '$year' And class = 10";
        $result = mysqli_query($conn,$sql);
        $num = mysqli_num_rows($result);
        if ($num == 0) {
            echo "<p class='text-center'>Results Not Yet Declared !!!</p>";
        }

        else{
            while($row = mysqli_fetch_assoc($result)){
                echo '
                <div class="col-md-4 d-flex justify-content-center">
                <div class="rcard shadow-sm text-left">
                <div class="details">
                    <img class=" text-center rounded-circle" width="130" height="130" src="../img/students/'.$row['imageurl'].'" alt="">
                    <p class="text-center" style="font-size:15px; width:100%;">'.$row['Name'].'</p>
                    <p class="text-center" style="font-size:12px; width:100%;">'.$row['Percentage'].'</p>
                
                </div>
                </div>
                </div>';
            }
        }
        ?>
                </div>
            </div>
        </div>


        <!-- <span>Rank: #'.$row['Rank'].'</span hidden><br>
                 <span class="">Percentage: '.$row['Percentage'].'%</span hidden> -->

    </div>
    <div class="Result">
        <div class="Rcontainer">
            <h2 class="text-center">ICSE Class 12<sup>th</sup> toppers <?php echo $year ?> </h2>

            <div class="resultcards d-flex justify-content-center">
                <div class="row">


    <?php

        $sql = "Select * from results where Fyear = '$year' And class = 12";
        $result = mysqli_query($conn,$sql);
        $num = mysqli_num_rows($result);
        if ($num == 0) {
            echo "<p class='text-center'>Results Not Yet Declared !!!</p>";
        }

        else{
            while($row = mysqli_fetch_assoc($result)){
                echo '
                <div class="col-md-4 d-flex justify-content-center">
                <div class="rcard shadow-sm text-left">
                <div class="details">
                    <img class=" text-center rounded-circle" width="130" height="130" src="'.$row['imageurl'].'" alt="">
                    <p style="font-size:15px; width:100%;">'.$row['Name'].'</p>
                    <span>Rank: #'.$row['Rank'].'</span>
                    <span class="">Percentage: '.$row['Percentage'].'%</span>
                </div>
                </div>
                </div>';
            }
        }
        ?>
                </div>
            </div>


        </div>

    </div>
    


</body>

</html>