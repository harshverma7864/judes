<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>

    <title>Welcome - Jude's College
    </title>

    <style>
        .row{
            width: 100%;
        }
    </style>
</head>
<body>

<?php include '../partials/_dbconnect.php';?>
    <!-- Navbar  -->
    <?php include '../partials/_navbar.php';?>
    <div class="noticeboard text-center">
        <h1><?php echo $_GET['h'] ?>'s Message</h1>
    </div>


    

    <?php
    $mtype = $_GET['h'];
    
      if ($mtype == "Principal") {
        echo `<p> <strong>“Education is not the learning of facts but , the training of the mind to think.”</strong> </p>
        <p style="float:right;">Albert Einstein</p>
    
    
        <p>
        Dear Parents/Gaurdians, <br>
            &nbsp;&nbsp;	&nbsp;&nbsp; 	&nbsp;&nbsp;	A good school is a social institution which keeps its door open fo all irrespective of religion,caste, colour, and financial status. Our vision is to recognise , cherish and refine individual abilities of students and transform them to successfull individuals. In this era of cut throat competition , it is of paramount importance to impart an integrated education and promote holistic development of students to prepare them for tackling obstacles that this competitive world offers.
            &nbsp;&nbsp;	&nbsp;&nbsp; 	&nbsp;&nbsp; 			St. Jude’s College , Unnao lays special emphasis on both academic and co-curricular activities to exhort and utilize the hidden talent of its pupils in the light of new Education Policy.
            &nbsp;&nbsp;	&nbsp;&nbsp; 	&nbsp;&nbsp;	St.Jude’s is the name that has redefined the concept of education in town. The school’s activity based teaching – learning methods encourage students to explore, discover , relate , solve problems and communicate confidently.
            &nbsp;&nbsp;	&nbsp;&nbsp; 	&nbsp;&nbsp;	Therefore with high expectations for the forthcoming session we wish your child a successfull year and blessed journey of education in our institution for which we expect the parents to co-operate with us as their support will be essential in monitoring and promoting the growth of their child. Let us together follow the rules and regulations of the college and ensure a good learning environment for our students.
    With lots of best wishes and prayers !
    
        </p>`;
      }
    

      
      else if ($mtype == "Director") {
       echo `<p>
       Dear Parents/Gaurdians <br>
       &nbsp;&nbsp;	&nbsp;&nbsp; 	&nbsp;&nbsp;  To motivate the weak, to address the average and to challenge the gifted is the true purpose of an educational institutional. A good school enriches the fertile soil of mind values of hard work and discipline so that saplings of good education may grow into strong tree and bear fruits of success. Education is not merely acquisition of facts but also values which helps us to improve different facets of mankind. It is this kind of holistic education which gives hope to the next generation.
		As stated by the famous philosopher ‘Francis Bacon’,”Histories make men wise; poets,witty; the mathematics , subtle; natural philosophy,deep; Moral,grave;logic and rhetoric,able to contend.”Thus we at St. Judes’s College, Unnao work at implementing a well balanced curriculum to ensure that the students are students are truely prepared to face the challenges of life along with touching the zenith of academic excellence. Our earnest endeavour is to help our students to grow into a true human with good skills and strong moral character.
</p>
`;
      }
    ?>

</body>
</html>