<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/about.css">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
    <title>Welcome - Jude's College
    </title>
</head>
<body>

<?php include '../partials/_dbconnect.php';?>
    <!-- Navbar  -->
    <?php include '../partials/_navbar.php';?>

    <div class="main-head text-center">
    <div class="container heade d-flex justify-content-center">
        <a href="_about.php?type=Anthem" class="mx-3">School Anthem</a>
        <a href="_about.php?type=RulesandRegulations" class="mx-3">Rules and Regulations</a>
        <a href="_about.php?type=dress" class="mx-3">Dress & Student Conduct</a>
    </div>
    <div class="my-4">
    <img class="rounded-circle" src="../img/teachers/founder.jpeg"  width="200" height="200" alt="">
    </div>
    <p style=" font-size:22px;">Founder, Late Mr. M.N. Azeem</p>
    <div style=" border:3px solid grey;" class="vacancies">
            <p >"Success starts in the heart. Get your motives and priorities right, and you're half way there. Education is the Drawing out of the best in man, in mind, body and spirit."</p>
    </div>
    
    <div>
        <h1 class="my-4 py-4">About the College</h1>
    </div>

    <div style="width: 80%; margin: auto; text-align: left;">
    Established in July 1975, St. Jude's College, Unnao was founded with the tireless efforts and dedication of Late. Mr M.N. Azeem (a member of India's famous La Martiniere College, Lucknow). The College is a co-educational English medium institute affiliated with the Council for the Indian School Certificate Examinations (CISCE), New Delhi. The College was set up with a mission to nurture children with a sound, pragmatic, career-oriented, quality education through progressive techniques and innovative curricula that will help them grow as balanced human beings equipped with moral fibre and skills, to excel in any changed situation in the world. Following its mission, the college is equipped with excellent facilities to impart quality academic, aesthetics, and sporting excellence. The college readily provides the children with adequate opportunities to explore their potential and talents with great mentoring from professionally qualified and skilled teachers as per the instructions directed by the council. <br><br>
    <h2>Infrastructure:</h2>
    The St Jude’s College is the first smart institution in the town that offers high-tech communication facilities right from its primary to higher secondary classes. Key features of our infrastructure are mentioned hereunder:<br><br>
    
    <h2>Sports Excellence:</h2> The College has its building with an extensive playground, football court, and other outdoor activities. <br>
    <h2>The Laboratories:</h2> Well-equipped Chemistry, Physics and Biology labs are set to impart practical education up to ISC level. <br>
    <h2>The Central Library:</h2>The college has a well-stocked library set-up with wholesome reference books on topics such as literature, sciences, politics, arts, culture, and human sciences including thousands of other books focusing on creative reading, writing and researching.<br>
    <h2>Computer Centre:</h2> The College has its very own fully developed Computer Centre that is well equipped to impart awareness on modern computerized software and technology.<br><br><br>
    Additionally, extra-curricular activities, workshops, training and mentor visits are organized to familiarize students with the nuances of the fast-paced competitive world outside.   <br>
    </div> <br>



    <h2>Mangerial Heads</h2>

    <div class="d-flex justify-content-center mheads">

            <div class="row">
                <?php 

                $sql = "select * from staff where section = 'managerial'";
                $result = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($result)){
                echo '
                <div class="col-md-4">
                <a style="text-decoration:none; color: black;" href="./messages.php?soid='.$row['sno'].'">
                <div class="img text-center">
                    <img height="150" width="150" class="rounded-circle" src="../img/teachers/'.$row['imageurl'].'"  width="200" height="200" alt="">
                    <p style="font-size: 25px;">'.$row['Name'].'</p>
                    <p>'.$row['designation'].'</p>
                </div>
                </a>
                </div>';
                }

                ?>

            </div>
    </div>

        <h2>Teachers & Staff</h2>
        <div class="row" style="width:80%; margin:auto;">
            <?php 

            $sql2 = "select * from staff where section = 'teacher'";
            $result2 = mysqli_query($conn,$sql2);
            while($row2 = mysqli_fetch_assoc($result2)){
            echo '
            <div class="col-md-3">
            <div class="d-flex justify-content-center mheads">
                <div class="img text-center" >
                    <img class="rounded-circle" height="150" width="150" src="../img/teachers/'.$row2['imageurl'].'"  width="200" height="200" alt="">
                    <p style="font-size: 15px;">'.$row2['Name'].'</p>
                </div>
            </div>
            </div>
            ';
        }
        ?>

    </div>


    <?php include '../partials/_footer.php'; ?>
    
</body>

</html>



