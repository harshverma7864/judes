<?php
    include '../partials/_dbconnect.php';


    $msg = $_POST['message'];
    $usermail = $_POST['usermail'];
    $usercontact = $_POST['usercontact'];

    $sql = "INSERT INTO `userqueries` (`sno`, `Useremail`, `Usercontact`, `query`) VALUES (NULL, '$usermail', '$usercontact', '$msg')";

    $result = mysqli_query($conn,$sql);

    mail("harshverma7864@gmail.com","User Query",$msg);
    
    if($result){
        $alert = "Please check your mail for the reply of this query";
        header("location: /php/contact.php?alert=$alert");
    }



?>