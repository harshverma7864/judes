<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "jude";

$conn = mysqli_connect($servername, $username, $password, $database);

if($conn){

}
?>
