


    <nav class="px-3 navbar navbar-expand-lg shadow-lg navbar-light bg-light">
        
  <div class="container-fluid">
  <a href="" class="navbar-brand"><li style="list-style:none;"><img src="/jude/img/stlogonew.png" width="30" height="30"><span class="sclname"> St. Jude's College</span></li></a>
    <!-- <a class="navbar-brand" href="#">Navbar</a> -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/jude/index.php"><b>Home</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/jude/php/results.php?yr=2019-20"><b>Results</b></a>
        </li>
        <li class="nav-item">
        <a style='text-decoration:none; color:black;' href="" class="nav-link">
        <div class="dropdown">
  <a style='text-decoration:none; color:black;' class=" dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
   Messages
  </a>

  <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <li><a class="dropdown-item" href="/jude/php/messages.php?h=Principal">Princpal's Message</a></li>
    <li><a class="dropdown-item" href="/jude/php/messages.php?h=Director">Director's Message</a></li>
  </ul>
</div>
        </a>


          
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/jude/php/schedule.php"><b>Schedule</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/jude/php/gallery.php"><b>Gallery</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/jude/php/about.php"><b>About</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/jude/php/contact.php"><b>Contact</b></a>
        </li>
      </ul>
    </div>
  </div>
</nav>
