
        <footer class="foot">
                <h2><b><img src="img/stlogonew.png" width="30" height="30"> St. Jude's College Since 1975, Unnao</b></h2>
                <h3><b>C/O La Martiniere College, Lucknow</b></h3>
                <h1>Crafted By KBN Software Pvt. Ltd.</h1>

        </footer>