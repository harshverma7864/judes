<?php

$servername = "localhost";
$username = "kbnsoftw_Jud_Admin";
$password = "Jud#458Admin*2022";
$database = "kbnsoftw_judes";

$conn = mysqli_connect($servername, $username, $password, $database);

?>
