<?php



?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../bootstrap-5.1.3-dist/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script src="../bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Notice  - stjudes</title>
  </head>
  <body>

  <?php include '../partials/_navbar.php'; ?>
  <?php

if(isset($_GET['alert'])){
    echo '   <div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Thank You</strong> '.$_GET['alert'].'
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}

?>

<br><br>
<form action="../partials/_updatetable.php?type=notice" method="post">
  <div class="container">
<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Type Notice : </label>
  <textarea name="notice" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
</div>

<button type="submit" class="btn btn-primary">Publish</button>
</form>

</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>